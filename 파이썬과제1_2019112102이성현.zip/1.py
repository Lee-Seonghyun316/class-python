# 1번
std = 20  # 학생 수
price = 1000  # 인당 간식 비
sum = std*price  # 총 식비
print(sum)
