# 5
# =이용 곱하기 이용 이름은 자기이름으로 print(저는 , name, 입니다)함수 쓰고 변수 사용
name = "이성현"
a = "="
aa = a*50
print(aa)
print("저는 파이썬 수업을 듣는 ", name, "입니다. ")
print(aa)
